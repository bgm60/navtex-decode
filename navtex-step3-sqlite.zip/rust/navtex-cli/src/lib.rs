//! Building blocks of the NAVTEX command-line program.
//!
//! The decoding itself lives in `navtex-core`. This crate adds what is
//! around it: the signal-quality meter, the assembly of characters into
//! lines, and (in later steps) the outputs, input and settings.

pub mod console;
pub mod lines;
pub mod pipeline;
pub mod quality;
pub mod sqlitelog;
pub mod textlog;
pub mod utc;

#[cfg(test)]
mod testutil;
